<?php
$spname="�Ƹ�ͨ˫�ӿڲ���";
$partner = "";
$key = "";
$return_url = "http://localhost/return_url.php";
$notify_url = "http://localhost/notify_url.php";
?>